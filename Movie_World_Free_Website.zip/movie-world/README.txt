MOVIE WORLD — FREE STARTER WEBSITE

1. Open index.html in a browser to preview the website.
2. To publish for free with GitHub Pages:
   - Create/sign in to a GitHub account.
   - Create a public repository named movie-world (or another name).
   - Upload index.html to the repository's root.
   - Open repository Settings > Pages.
   - Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
   - Wait for GitHub to show the published site URL in Settings > Pages.
3. This is a static template. It does not host movie files or provide an admin panel.
4. Use only your own or authorized movie files and download links. Sample trailer buttons open YouTube search; Watch options opens JustWatch.
